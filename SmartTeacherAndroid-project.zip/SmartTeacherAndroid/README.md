# دفتر المدرس الذكي — Android

هذا المشروع يحوّل نسخة `index.html` الحالية إلى تطبيق Android أصلي عبر WebView مع الحفاظ على واجهة ووظائف HTML/JavaScript الحالية.

## المتطلبات للبناء
- Android Studio حديث
- Android SDK 35
- JDK 17

## البناء
افتح المجلد في Android Studio ثم:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

ملف APK الناتج سيكون داخل:
app/build/outputs/apk/debug/app-debug.apk

ملاحظة: النسخة الحالية تعتمد على موارد خارجية في HTML (Cairo / Font Awesome / html2pdf.js) وعلى رابط Google Apps Script للتحقق من الاشتراك، لذلك تحتاج اتصال إنترنت لهذه الأجزاء.
